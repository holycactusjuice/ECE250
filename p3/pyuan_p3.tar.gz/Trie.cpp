#include "Trie.h"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stack>
#include <string>
#include <vector>

#include "IllegalException.h"
#include "Node.h"
#include "ece250_socket.h"

// Constructor: Initializes the Trie with an empty root node and zero
// classifications.
Trie::Trie() : root(new Node()), classifications(0) {}

// Destructor: Frees the memory used by the root node, which recursively deletes
// all children.
Trie::~Trie() { delete root; }

// Validates input strings, ensuring they do not contain uppercase characters.
// Throws an IllegalException if an invalid character is found.
void Trie::validateInput(std::string input) {
    for (char c : input) {
        if (isupper(c))
            throw IllegalException();  // Input must not have uppercase letters.
    }
}

// Loads classifications from a file and inserts them into the Trie.
// Returns "success" if all lines are processed correctly.
std::string Trie::load(std::string filename) {
    std::ifstream dataFile(filename);  // Open the file for reading.
    std::string label;

    // Read each line and insert it into the Trie.
    while (std::getline(dataFile, label)) {
        insert(label);
    }

    dataFile.close();  // Close the file after processing.
    return "success";
}

// Inserts a classification string into the Trie.
// Returns "success" if inserted correctly, or "failure"/"illegal argument"
// otherwise.
std::string Trie::insert(std::string classification) {
    if (classification.empty())
        return "failure";  // Empty classifications are invalid.

    // Validate the classification string.
    try {
        validateInput(classification);
    } catch (IllegalException&) {
        return "illegal argument";
    }

    // Split the classification into individual labels.
    std::vector<std::string> labels;
    std::istringstream stream(classification);
    std::string label;
    while (std::getline(stream, label, ',')) {
        labels.push_back(label);
    }

    Node* curr = root;            // Start at the root node.
    bool newNodeCreated = false;  // Track if new nodes are added.

    // Traverse or extend the Trie based on the labels.
    for (const std::string& label : labels) {
        Node* child = nullptr;

        // Check if the label exists among the current node's children.
        for (Node* existingChild : curr->getChildren()) {
            if (existingChild->getLabel() == label) {
                child = existingChild;
                break;
            }
        }

        if (child) {
            curr = child;  // Move to the existing child node.
        } else {
            // Create a new child node if the label doesn't exist.
            Node* newNode = new Node();
            newNode->setLabel(label);
            curr->addChild(newNode);
            curr = newNode;
            newNodeCreated = true;
        }
    }

    // Update the classification count based on whether new nodes were created.
    if (newNodeCreated || !curr->isTerminal()) {
        classifications++;
    }

    // If no new nodes were added and the current node is already terminal,
    // insertion fails.
    if (!newNodeCreated && curr->isTerminal()) {
        return "failure";
    }

    return "success";
}

// Classifies an input string by navigating the Trie and returning the
// classification path. Returns "illegal argument" if the input is invalid.
std::string Trie::classify(std::string input) {
    // Validate the input string.
    try {
        validateInput(input);
    } catch (IllegalException&) {
        return "illegal argument";
    }

    Node* curr = root;  // Start at the root node.
    std::vector<std::string> resultVector;

    // Traverse the Trie until reaching a terminal node or no children remain.
    while (!curr->isTerminal()) {
        if (curr->getChildren().empty()) break;

        // Gather possible labels from the current node's children.
        std::string possibleLabels;
        for (const auto& child : curr->getChildren()) {
            possibleLabels += child->getLabel() + ",";
        }
        possibleLabels.pop_back();  // Remove trailing comma.

        std::string targetLabel = labelText(
            input, possibleLabels);  // Get target label (custom logic).

        bool found = false;

        // Move to the child with the matching label.
        for (const auto& child : curr->getChildren()) {
            if (child->getLabel() == targetLabel) {
                curr = child;
                resultVector.push_back(targetLabel);
                found = true;
                break;
            }
        }

        if (!found) break;  // Stop if the label is not found.
    }

    // Concatenate the result vector into a comma-separated string.
    std::string result;
    for (size_t i = 0; i < resultVector.size(); ++i) {
        result += resultVector[i];
        if (i < resultVector.size() - 1) result += ",";
    }

    return result;
}

// Erases a classification from the Trie.
// Returns "success" if erased successfully, or "failure" otherwise.
std::string Trie::erase(std::string classification) {
    // Validate the input string.
    try {
        validateInput(classification);
    } catch (IllegalException&) {
        return "illegal argument";
    }

    if (isEmpty()) return "failure";  // Can't erase from an empty Trie.

    // Split the classification into labels.
    std::vector<std::string> labels;
    std::istringstream stream(classification);
    std::string label;
    while (std::getline(stream, label, ',')) {
        labels.push_back(label);
    }

    if (labels.empty()) return "failure";

    Node* curr = root;
    std::vector<Node*> path{curr};  // Track the path for backtracking.
    std::vector<int> childIndex;    // Track child indices along the path.

    // Traverse the Trie to find the node to erase.
    for (const std::string& label : labels) {
        bool found = false;
        const auto& children = curr->getChildren();

        for (size_t i = 0; i < children.size(); ++i) {
            if (children[i] && children[i]->getLabel() == label) {
                curr = children[i];
                path.push_back(curr);
                childIndex.push_back(i);
                found = true;
                break;
            }
        }

        if (!found) return "failure";  // Classification path not found.
    }

    if (!curr->isTerminal())
        return "failure";  // Only terminal nodes can be erased.

    // Remove the terminal node and backtrack to clean up empty parents.
    Node* parent = path[path.size() - 2];
    int lastIndex = childIndex.back();

    parent->removeChild(lastIndex);  // Remove the terminal node.
    classifications--;

    // Remove unnecessary parent nodes along the path.
    for (size_t i = path.size() - 2; i > 0; --i) {
        Node* node = path[i];
        if (node->getChildren().empty()) {
            Node* grandparent = path[i - 1];
            int parentIndex = childIndex[i - 1];
            grandparent->removeChild(parentIndex);
        } else {
            break;
        }
    }

    return "success";
}

// Prints all classifications in the Trie in a serialized format.
std::string Trie::print() {
    if (isEmpty()) return "trie is empty";

    std::stack<Node*> nodeStack;
    nodeStack.push(root);

    std::stack<std::vector<std::string>> pathStack;
    pathStack.push({});

    std::string result;

    // Depth-first traversal of the Trie.
    while (!nodeStack.empty()) {
        Node* curr = nodeStack.top();
        nodeStack.pop();

        std::vector<std::string> path = std::move(pathStack.top());
        pathStack.pop();

        if (curr->isTerminal()) {
            if (!result.empty()) result += "_";
            result += joinPath(path);
        }

        const auto& children = curr->getChildren();
        for (auto it = children.rbegin(); it != children.rend(); ++it) {
            nodeStack.push(*it);

            std::vector<std::string> newPath = path;
            newPath.push_back((*it)->getLabel());
            pathStack.push(newPath);
        }
    }

    if (result.back() != '_') result += "_";
    return result;
}

// Checks if the Trie is empty and returns an appropriate message.
std::string Trie::empty() {
    return "empty " + std::to_string(isEmpty() ? 1 : 0);
}

// Clears the Trie, resetting it to an empty state.
std::string Trie::clear() {
    if (root) delete root;  // Free the existing Trie.
    root = new Node();      // Create a new root node.
    classifications = 0;
    return "success";
}

// Returns the number of classifications stored in the Trie.
std::string Trie::size() {
    return "number of classifications is " + std::to_string(classifications);
}

// Checks if the Trie is empty by verifying the classification count.
bool Trie::isEmpty() { return classifications == 0; }

// Joins a vector of strings into a comma-separated path string.
std::string Trie::joinPath(const std::vector<std::string>& path) {
    std::string joined;
    for (size_t i = 0; i < path.size(); ++i) {
        joined += path[i];
        if (i != path.size() - 1) joined += ",";
    }
    return joined;
}